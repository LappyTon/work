package me.seyit;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class NoMissClient implements ClientModInitializer {
    private static boolean enabled = true;
    private static class_304 toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.no-miss.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_N,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.method_1436()) {
                enabled = !enabled;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            class_2561.method_43470(enabled ? "§aNo Miss ON" : "§cNo Miss OFF"),
                            true
                    );
                }
            }
        });
    }

    public static boolean isEnabled() {
        return enabled;
    }
}