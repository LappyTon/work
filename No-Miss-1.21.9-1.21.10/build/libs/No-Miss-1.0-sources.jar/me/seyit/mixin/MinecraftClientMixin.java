package me.seyit.mixin;

import me.seyit.NoMissClient;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public class MinecraftClientMixin {
    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void onAttack(CallbackInfoReturnable<Boolean> cir) {
        class_310 mc = class_310.method_1551();

        if (!NoMissClient.isEnabled()) {
            return;
        }

        // No Miss: не бити в повітря
        if (mc.field_1765 == null
                || mc.field_1765.method_17783() != class_239.class_240.field_1331) {
            cir.setReturnValue(false);
            return;
        }

        // No Weak Attack: тільки для алмазного та незеритового мечів
        if (mc.field_1724 != null) {
            var item = mc.field_1724.method_6047().method_7909();

            if ((item == class_1802.field_8802 || item == class_1802.field_22022)
                    && mc.field_1724.method_7261(0.0f) < 0.848f) {
                cir.setReturnValue(false);
            }
        }
    }
}